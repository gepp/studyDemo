package javatuning.ch2.decorator;

public interface IPacketCreator {
	public String handleContent();
}

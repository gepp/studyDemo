package javatuning.ch2.proxy;

public interface IDBQuery {
	String request();
}

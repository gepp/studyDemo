package javatuning.ch2.observor;

public class Event {

}

package javatuning.ch2.flyweight;

public interface IReportManager {
	public String createReport();
}

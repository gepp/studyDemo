package javatuning.ch5.memory;

public class MyClassLoader extends ClassLoader {
}
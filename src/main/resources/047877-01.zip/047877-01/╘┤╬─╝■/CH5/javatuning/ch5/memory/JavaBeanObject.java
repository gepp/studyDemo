package javatuning.ch5.memory;

public class JavaBeanObject {
	private String name = "java";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

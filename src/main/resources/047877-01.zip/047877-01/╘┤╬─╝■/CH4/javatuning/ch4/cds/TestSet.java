package javatuning.ch4.cds;

import static org.junit.Assert.*;

import java.util.Collections;

import org.junit.Test;

public class TestSet {

	@Test
	public void test() {
		//Collections.synchronizedSet(s)
	}

}

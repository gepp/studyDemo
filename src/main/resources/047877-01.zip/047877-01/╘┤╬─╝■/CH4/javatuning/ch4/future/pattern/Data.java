package javatuning.ch4.future.pattern;

public interface Data {
    public String getResult();
}

package kilim.test.ex;

public class ExFrame {
    double[] kitchensink(int i, long j, boolean b, double d, String[][] s) {
        return null;
    }
}
package kilim;

public class NotPausable extends RuntimeException {
    private static final long serialVersionUID = 1L;
}

/* Copyright (c) 2006, Sriram Srinivasan
 *
 * You may distribute this software under the terms of the license 
 * specified in the file "License"
 */

package kilim;


public class KilimException extends RuntimeException {
    private static final long serialVersionUID = 7856831331381969854L;

    public KilimException(String msg) {super(msg);}
}

package kilim.test.ex;

public class ExD extends ExB {

}

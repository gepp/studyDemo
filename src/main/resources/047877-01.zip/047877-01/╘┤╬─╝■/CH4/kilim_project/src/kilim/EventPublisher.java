package kilim;

public interface EventPublisher {
}

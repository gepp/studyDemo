package kilim;

public class ShutdownException extends Exception {
    private static final long serialVersionUID = 1L;

  public ShutdownException() {
    // TODO Auto-generated constructor stub
  }
}

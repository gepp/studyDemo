package kilim.test.ex;

public class ExC extends ExA {

}

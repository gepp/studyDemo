package kilim.test.ex;

public class ExB extends ExA {

}

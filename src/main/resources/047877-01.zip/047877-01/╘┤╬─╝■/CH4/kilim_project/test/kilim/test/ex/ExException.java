package kilim.test.ex;

public class ExException extends Exception {
    private static final long serialVersionUID = 1L;

    public ExException(String message) {
        super(message);
    }
}
